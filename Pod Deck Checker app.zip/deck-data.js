// Mock data for Pod Deck Checker — La guía del Yoryi
// card: [qty, name, mana, cmc, type(C I S A E P L), cat, price€, badge?]
export const TYPES = {C:{es:'Criaturas',en:'Creatures'},I:{es:'Instantáneos',en:'Instants'},S:{es:'Conjuros',en:'Sorceries'},A:{es:'Artefactos',en:'Artifacts'},E:{es:'Encantamientos',en:'Enchantments'},P:{es:'Planeswalkers',en:'Planeswalkers'},L:{es:'Tierras',en:'Lands'}};
export const TYPE_ORDER = ['C','I','S','A','E','P','L'];
export const CATS = {land:{es:'Tierras',en:'Lands'},ramp:{es:'Rampa',en:'Ramp'},draw:{es:'Robo de cartas',en:'Card draw'},rem:{es:'Remoción',en:'Removal'},wipe:{es:'Barridos',en:'Board wipes'},prot:{es:'Protección',en:'Protection'},ctr:{es:'Contrahechizos',en:'Counterspells'},tut:{es:'Tutores',en:'Tutors'},sac:{es:'Sacrificio',en:'Sac outlets'},drain:{es:'Drenaje',en:'Drain'},tok:{es:'Fichas',en:'Tokens'},mot:{es:'Motores',en:'Engines'},eq:{es:'Equipos',en:'Equipment'}};

export const DIALS = [
 {k:'gc',name:{es:'Cambia-partidas',en:'Game changers'},z:[1,2,1],help:{
  es:'Cartas de la lista oficial de game changers: generan una ventaja desproporcionada por sí solas. El primero es gratis; cada uno más cuesta 2 puntos.',
  en:'Cards on the official game-changer list: they generate outsized advantage on their own. The first one is free; each extra costs 2 points.'}},
 {k:'ext',name:{es:'Turnos extra',en:'Extra turns'},z:[1,2,2],help:{
  es:'Los turnos extra dejan a la mesa mirando. Cada carta de turno extra cuesta 1 punto y además exige justificación en mesa.',
  en:'Extra turns leave the table watching. Each extra-turn card costs 1 point and also needs table justification.'}},
 {k:'tut',name:{es:'Tutores',en:'Tutors'},z:[2,3,2],help:{
  es:'Los tutores hacen el mazo más consistente: encuentran siempre la misma carta y aceleran el plan. Los 2 primeros son gratis; del tercero en adelante, 1 punto cada uno. Si quieres soltar puntos, cámbialos por robo genérico.',
  en:'Tutors make the deck more consistent: they always find the same card and speed up the plan. The first 2 are free; from the third on, 1 point each. To shed points, swap them for generic card draw.'}},
 {k:'stax',name:{es:'Stax',en:'Stax'},z:[1,2,2],help:{
  es:'Las piezas de stax frenan a toda la mesa, no solo al que va ganando. La primera es gratis; la segunda cuesta 2 puntos; la tercera está prohibida en este pod.',
  en:'Stax pieces slow the whole table, not just whoever is winning. The first is free; the second costs 2 points; a third is forbidden in this pod.'}},
 {k:'ctr',name:{es:'Contrahechizos',en:'Counterspells'},z:[3,3,2],help:{
  es:'Hasta 4 contrahechizos son defensa propia razonable. A partir de ahí el mazo empieza a controlar la mesa: 1 punto por cada uno extra. Pregúntate: ¿protegen tu plan o frenan al pod entero?',
  en:'Up to 4 counterspells is reasonable self-defense. Beyond that the deck starts controlling the table: 1 point each. Ask yourself: do they protect your plan or hold the whole pod back?'}},
 {k:'wipe',name:{es:'Barridos',en:'Board wipes'},z:[4,3,1],help:{
  es:'Los barridos mantienen la mesa sana en mazos lentos. Hasta 4 son gratis; más de 4 sugiere un plan de control puro: 1 punto cada uno.',
  en:'Board wipes keep the table healthy in slower decks. Up to 4 are free; more than 4 suggests a pure control plan: 1 point each.'}},
 {k:'free',name:{es:'Hechizos gratis',en:'Free spells'},z:[1,2,2],help:{
  es:'Los hechizos gratis rompen la regla básica del maná: siempre puedes responder, incluso sin mana abierto. 1 punto cada uno.',
  en:'Free spells break the basic rule of mana: you can always respond, even fully tapped out. 1 point each.'}},
 {k:'fm',name:{es:'Maná rápido',en:'Fast mana'},z:[1,2,2],help:{
  es:'El maná rápido acelera los turnos clave y adelanta el mazo uno o dos turnos. Sol Ring es gratis por tradición; cada pieza más cuesta 1 punto.',
  en:'Fast mana accelerates key turns and puts the deck one or two turns ahead. Sol Ring is free by tradition; each extra piece costs 1 point.'}},
 {k:'c1_5',name:{es:'Cartas €1–5',en:'Cards €1–5'},z:[6,2,1],help:{
  es:'Volumen de cartas de €1–5: mide cuánto se ha optimizado el mazo por encima de un precon. Zona libre amplia — es sano mejorar el mazo poco a poco.',
  en:'Volume of €1–5 cards: measures how far the deck has been optimized past a precon. Wide free zone — upgrading gradually is healthy.'}},
 {k:'c10_20',name:{es:'Cartas €10–20',en:'Cards €10–20'},z:[4,2,1],help:{
  es:'Las cartas de €10–20 suelen ser los staples que suben el techo del mazo. Zona libre hasta 4; después, 1 punto por cada 2.',
  en:'€10–20 cards are usually the staples that raise the deck’s ceiling. Free up to 4; after that, 1 point per 2 cards.'}},
 {k:'c20_30',name:{es:'Cartas €20–30',en:'Cards €20–30'},z:[3,2,1],help:{
  es:'El escalón antes del límite duro de €30. Hasta 3 sin coste, pero vigílalas: con subidas de precio pueden cruzar el límite y pasar a necesitar aprobación de mesa.',
  en:'The step before the hard €30 cap. Up to 3 at no cost, but watch them: price spikes can push them over the cap, where they need table approval.'}}
];

export const BASECOMP = [['land',34,38],['ramp',8,12],['draw',8,12],['rem',8,11],['wipe',2,4],['prot',2,5]];

export const ARCH = [
 {k:'voltron',name:{es:'Voltron',en:'Voltron'},spec:[['prot',6,10],['eq',8,12]],
  desc:{es:'Un solo atacante enorme: tu comandante cargado de auras y equipos hasta matar de 21 de daño de comandante.',en:'One huge attacker: your commander stacked with auras and equipment until 21 commander damage kills.'},
  how:{es:'Prioriza protección barata (botas, capas) y robo que recargue la mano tras un barrido enemigo.',en:'Prioritize cheap protection (boots, capes) and draw that refills your hand after an enemy wipe.'},
  slots:{es:['Equipos/Auras 8–12','Protección 6–10','Robo 8–10'],en:['Equipment/Auras 8–12','Protection 6–10','Draw 8–10']}},
 {k:'aristocrats',name:{es:'Aristócratas',en:'Aristocrats'},spec:[['sac',5,8],['drain',4,6],['tok',8,12]],
  desc:{es:'Sacrifica tus propias criaturas para drenar vida a toda la mesa. Gana sin atacar.',en:'Sacrifice your own creatures to drain the whole table. Wins without attacking.'},
  how:{es:'Necesitas tres patas: salidas de sacrificio, material sacrificable (fichas) y drenajes tipo Blood Artist. Recursión antes que cartas caras.',en:'You need three legs: sac outlets, sac fodder (tokens) and Blood Artist–style drains. Recursion over expensive cards.'},
  slots:{es:['Salidas de sacrificio 5–8','Drenajes 4–6','Fichas 8–12'],en:['Sac outlets 5–8','Drains 4–6','Tokens 8–12']}},
 {k:'control',name:{es:'Control',en:'Control'},spec:[['ctr',6,10]],
  desc:{es:'Frena a la mesa con contrahechizos y barridos hasta cerrar con un finisher tardío.',en:'Slow the table with counterspells and wipes until a late finisher closes the game.'},
  how:{es:'Roba más que nadie, contesta solo lo que te mata y respeta el límite de contrahechizos del pod.',en:'Draw more than anyone, answer only what kills you, and respect the pod’s counterspell limits.'},
  slots:{es:['Contrahechizos 6–10','Barridos 3–5','Robo 10–14'],en:['Counterspells 6–10','Wipes 3–5','Draw 10–14']}},
 {k:'midrange',name:{es:'Midrange',en:'Midrange'},spec:[],
  desc:{es:'Cartas de valor jugadas en curva: cada permanente genera ventaja por sí solo.',en:'Value cards played on curve: every permanent generates advantage on its own.'},
  how:{es:'Curva 2–4 densa, remoción flexible y amenazas que sobreviven a un barrido.',en:'Dense 2–4 curve, flexible removal, and threats that survive a wipe.'},
  slots:{es:['Amenazas de valor 12–16','Remoción 8–11','Rampa 8–10'],en:['Value threats 12–16','Removal 8–11','Ramp 8–10']}},
 {k:'tokens',name:{es:'Fichas a lo ancho',en:'Go-Wide Tokens'},spec:[['tok',10,14]],
  desc:{es:'Inunda la mesa de fichas y gana con anthems que las convierten en un ejército real.',en:'Flood the board with tokens and win with anthems that turn them into a real army.'},
  how:{es:'Generadores repetibles > efectos de un solo uso; incluye protección contra barridos.',en:'Repeatable generators > one-shot effects; include wipe protection.'},
  slots:{es:['Generadores 10–14','Anthems 4–6','Protección 3–5'],en:['Generators 10–14','Anthems 4–6','Protection 3–5']}},
 {k:'aggro',name:{es:'Aggro',en:'Aggro'},spec:[],
  desc:{es:'Presión desde el turno 1: criaturas baratas y daño constante antes de que la mesa se estabilice.',en:'Pressure from turn 1: cheap creatures and constant damage before the table stabilizes.'},
  how:{es:'Curva bajísima (media < 2.5), pocas tierras que entran giradas y robo que no frene el ritmo.',en:'Very low curve (avg < 2.5), few tapped lands, and draw that doesn’t slow the tempo.'},
  slots:{es:['Criaturas ≤3 maná 20–26','Impulso/robo 6–8','Remoción 6–8'],en:['Creatures ≤3 mana 20–26','Impulse/draw 6–8','Removal 6–8']}},
 {k:'equipment',name:{es:'Equipos',en:'Equipment'},spec:[['eq',10,14]],
  desc:{es:'Un arsenal de equipos y portadores intercambiables: el valor vive en los objetos, no en las criaturas.',en:'An arsenal of equipment and interchangeable bearers: the value lives in the gear, not the creatures.'},
  how:{es:'Reduce costes de equipar, incluye portadores con evasión y recuperación de equipos destruidos.',en:'Cut equip costs, include evasive bearers, and recover destroyed equipment.'},
  slots:{es:['Equipos 10–14','Portadores 12–16','Tutores de equipo 2–4'],en:['Equipment 10–14','Bearers 12–16','Gear tutors 2–4']}},
 {k:'lifegain',name:{es:'Ganavidas',en:'Lifegain'},spec:[['drain',4,6]],
  desc:{es:'Convierte cada punto de vida ganado en cartas, fichas o drenaje. La vida es tu motor, no tu escudo.',en:'Turn every life point gained into cards, tokens or drain. Life is your engine, not your shield.'},
  how:{es:'Necesitas pagos (payoffs) repetibles; ganar vida sin pagos no hace nada en Commander.',en:'You need repeatable payoffs; gaining life without payoffs does nothing in Commander.'},
  slots:{es:['Fuentes de vida 10–14','Pagos 6–9','Drenajes 4–6'],en:['Life sources 10–14','Payoffs 6–9','Drains 4–6']}},
 {k:'spellslinger',name:{es:'Spellslinger',en:'Spellslinger'},spec:[['mot',6,10],['tok',3,6]],
  desc:{es:'Instantáneos y conjuros en cadena, con permanentes que premian cada hechizo lanzado.',en:'Chained instants and sorceries, with permanents that reward every spell cast.'},
  how:{es:'Motores primero (Guttersnipe, Archmage), luego densidad de hechizos baratos que los alimenten.',en:'Engines first (Guttersnipe, Archmage), then a density of cheap spells to feed them.'},
  slots:{es:['Motores 6–10','Hechizos ≤2 maná 18–24','Robo 10–14'],en:['Engines 6–10','Spells ≤2 mana 18–24','Draw 10–14']}},
 {k:'counters',name:{es:'Contadores +1/+1',en:'+1/+1 Counters'},spec:[],
  desc:{es:'Crece tus criaturas con contadores y multiplica el efecto con proliferar y señores.',en:'Grow your creatures with counters and multiply the effect with proliferate and lords.'},
  how:{es:'Sinergia > poder individual: cada carta debería poner o aprovechar contadores.',en:'Synergy > individual power: every card should add or exploit counters.'},
  slots:{es:['Fuentes de contadores 14–18','Proliferar 4–6','Pagos 6–8'],en:['Counter sources 14–18','Proliferate 4–6','Payoffs 6–8']}},
 {k:'reanimator',name:{es:'Reanimator',en:'Reanimator'},spec:[],
  desc:{es:'Tira criaturas enormes al cementerio y devuélvelas a la mesa por una fracción de su coste.',en:'Dump huge creatures into the graveyard and return them to play for a fraction of their cost.'},
  how:{es:'Equilibra tres partes: descarte/molino propio, hechizos de reanimación y objetivos que ganen solos.',en:'Balance three parts: self-discard/mill, reanimation spells, and targets that win on their own.'},
  slots:{es:['Reanimación 6–9','Autodescarte 8–10','Objetivos gordos 6–8'],en:['Reanimation 6–9','Self-discard 8–10','Fat targets 6–8']}},
 {k:'generic',name:{es:'Genérico',en:'Generic'},spec:[],
  desc:{es:'Un poco de todo: bueno para precons y primeros mazos. Sin plan dominante.',en:'A bit of everything: good for precons and first decks. No dominant plan.'},
  how:{es:'Cumple los mínimos de composición base y busca poco a poco una identidad.',en:'Meet the base composition minimums and slowly find an identity.'},
  slots:{es:['Composición base','Curva media 3.0–3.5'],en:['Base composition','Avg curve 3.0–3.5']}}
];

const A_CARDS = [
 [14,'Swamp','',0,'L','land',0.1],[12,'Plains','',0,'L','land',0.1],[1,'Command Tower','',0,'L','land',0.9],[1,'Evolving Wilds','',0,'L','land',0.2],[1,'Temple of Silence','',0,'L','land',0.8],[1,'Orzhov Guildgate','',0,'L','land',0.1],[1,'Isolated Chapel','',0,'L','land',3.5],[1,'Caves of Koilos','',0,'L','land',1.5],[1,'Scoured Barrens','',0,'L','land',0.2],[1,'Forsaken Sanctuary','',0,'L','land',0.3],[1,'Bojuka Bog','',0,'L','land',0.4],[1,"Rogue's Passage",'',0,'L','land',0.3],
 [1,'Blood Artist','1B',2,'C','drain',1.2],[1,'Zulaport Cutthroat','1B',2,'C','drain',0.9],[1,'Cruel Celebrant','WB',2,'C','drain',1.1],[1,'Vito, Thorn of the Dusk Rose','2B',3,'C','drain',3.5],[1,'Suture Priest','1W',2,'C','drain',1.0],[1,'Serrated Scorpion','B',1,'C','drain',0.2],[1,'Kambal, Consul of Allocation','1WB',3,'C','drain',2.5],[1,'Marionette Master','4BB',6,'C','drain',2.0],
 [1,'Viscera Seer','B',1,'C','sac',0.8],[1,'Carrion Feeder','B',1,'C','sac',0.7],[1,'Priest of Forgotten Gods','1B',2,'C','sac',1.8],[1,"Ashnod's Altar",'3',3,'A','sac',7.5],
 [1,'Reassembling Skeleton','1B',2,'C','mot',0.5],[1,'Butcher of Malakir','5BB',7,'C','mot',1.5],[1,'Teysa Karlov','2WB',4,'C','mot',3.5],[1,'Elenda, the Dust Rose','2WB',4,'C','mot',12],
 [1,'Pitiless Plunderer','3B',4,'C','ramp',4.5],[1,'Sifter of Skulls','3B',4,'C','ramp',0.8],[1,'Sol Ring','1',1,'A','ramp',1.8,'FM'],[1,'Arcane Signet','2',2,'A','ramp',0.8],[1,'Orzhov Signet','2',2,'A','ramp',0.5],[1,'Talisman of Hierarchy','2',2,'A','ramp',1.2],[1,'Mind Stone','2',2,'A','ramp',0.4],
 [1,'Midnight Reaper','2B',3,'C','draw',1.0],[1,'Grim Haruspex','2B',3,'C','draw',1.5],[1,'Mentor of the Meek','2W',3,'C','draw',1.0],[1,'Skullclamp','1',1,'A','draw',4.9],[1,'Phyrexian Arena','1BB',3,'E','draw',6],[1,'Village Rites','B',1,'I','draw',0.3],[1,'Deadly Dispute','1B',2,'I','draw',0.9],[1,"Night's Whisper",'1B',2,'S','draw',2.8],[1,'Sign in Blood','BB',2,'S','draw',0.5],[1,'Costly Plunder','1B',2,'I','draw',0.2],
 [1,'Ministrant of Obligation','2W',3,'C','tok',0.3],[1,'Hunted Witness','W',1,'C','tok',0.2],[1,'Doomed Traveler','W',1,'C','tok',0.2],[1,'Doomed Dissenter','1B',2,'C','tok',0.2],[1,'Sengir Autocrat','3B',4,'C','tok',0.4],[1,'Ogre Slumlord','4B',5,'C','tok',0.9],[1,'Requiem Angel','5W',6,'C','tok',0.5],[1,'Open the Graves','3BB',5,'E','tok',1.2],[1,'Promise of Bunrei','2W',3,'E','tok',0.6],
 [1,'Swords to Plowshares','W',1,'I','rem',1.6],[1,'Path to Exile','W',1,'I','rem',2.2],[1,'Anguished Unmaking','1WB',3,'I','rem',2.5],[1,'Mortify','1WB',3,'I','rem',0.4],[1,'Generous Gift','2W',3,'I','rem',1.8],[1,'Feed the Swarm','1B',2,'S','rem',0.7],[1,'Bone Splinters','B',1,'S','rem',0.2],
 [1,'Diabolic Tutor','3B',4,'S','tut',0.5,'TUT'],[1,'Final Parting','4B',5,'S','tut',0.4,'TUT'],[1,'Scheming Symmetry','B',1,'S','tut',1.5,'TUT'],
 [1,'Fumigate','4W',5,'S','wipe',0.6,'WIPE'],[1,'Toxic Deluge','2B',3,'S','wipe',16,'WIPE'],[1,'Day of Judgment','2WW',4,'S','wipe',2.5,'WIPE'],
 [1,'Grave Pact','1BB',3,'E','mot',9],[1,'Dictate of Erebos','3BB',5,'E','mot',7],[1,'Authority of the Consuls','W',1,'E','mot',4],[1,'Zealous Persecution','WB',2,'I','mot',0.8],[1,'Tortured Existence','B',1,'E','mot',0.5],
 [1,'Ghostly Prison','2W',3,'E','prot',3],[1,'Malakir Rebirth','B',1,'I','prot',2.0],[1,"Kaya's Ghostform",'B',1,'E','prot',0.3]
];

const B_CARDS = [
 [10,'Island','',0,'L','land',0.1],[8,'Plains','',0,'L','land',0.1],[6,'Swamp','',0,'L','land',0.1],[1,'Command Tower','',0,'L','land',0.9],[1,'Evolving Wilds','',0,'L','land',0.2],[1,'Temple of Deceit','',0,'L','land',0.5],[1,'Temple of Silence','',0,'L','land',0.8],[1,'Temple of Enlightenment','',0,'L','land',0.5],[1,'Azorius Guildgate','',0,'L','land',0.1],[1,'Dimir Guildgate','',0,'L','land',0.1],[1,'Orzhov Guildgate','',0,'L','land',0.1],[1,'Glacial Fortress','',0,'L','land',2.5],[1,'Drowned Catacomb','',0,'L','land',2.0],[1,'Isolated Chapel','',0,'L','land',3.5],[1,'Exotic Orchard','',0,'L','land',1.5],
 [1,'Counterspell','UU',2,'I','ctr',1.1,'CTR'],[1,'Negate','1U',2,'I','ctr',0.3,'CTR'],[1,'Swan Song','U',1,'I','ctr',2.5,'CTR'],[1,"Dovin's Veto",'WU',2,'I','ctr',2.8,'CTR'],[1,'Arcane Denial','1U',2,'I','ctr',1.0,'CTR'],
 [1,'Rhystic Study','2U',3,'E','draw',26,'GC'],[1,'Smothering Tithe','3W',4,'E','mot',22,'GC'],
 [1,'Mystical Tutor','U',1,'I','tut',6,'TUT'],[1,'Enlightened Tutor','W',1,'I','tut',14,'TUT'],[1,'Idyllic Tutor','2W',3,'S','tut',8,'TUT'],
 [1,'Supreme Verdict','1WWU',4,'S','wipe',5,'WIPE'],[1,'Day of Judgment','2WW',4,'S','wipe',2.5,'WIPE'],[1,'Fumigate','4W',5,'S','wipe',0.6,'WIPE'],[1,'Toxic Deluge','2B',3,'S','wipe',16,'WIPE'],
 [1,'Swords to Plowshares','W',1,'I','rem',1.6],[1,'Path to Exile','W',1,'I','rem',2.2],[1,'Anguished Unmaking','1WB',3,'I','rem',2.5],[1,'Despark','WB',2,'I','rem',0.4],[1,'Prismatic Ending','W',1,'S','rem',2.2],[1,'Skyclave Apparition','1WW',3,'C','rem',3.5],[1,'Oblivion Ring','2W',3,'E','rem',0.3],[1,'Banishing Light','2W',3,'E','rem',0.9],[1,'Detention Sphere','1WU',3,'E','rem',2.0],[1,'Sunblast Angel','4WW',6,'C','rem',0.5],[1,'Palace Jailer','3W',4,'C','rem',1.0],
 [1,'Fact or Fiction','3U',4,'I','draw',0.5],[1,'Brainstorm','U',1,'I','draw',1.0],[1,'Preordain','U',1,'S','draw',1.2],[1,'Opt','U',1,'I','draw',0.3],[1,'Serum Visions','U',1,'S','draw',1.5],[1,'Think Twice','1U',2,'I','draw',0.2],[1,"Chemister's Insight",'3U',4,'I','draw',0.3],[1,'Impulse','1U',2,'I','draw',0.9],[1,'Azorius Charm','WU',2,'I','draw',0.3],[1,'Baleful Strix','UB',2,'C','draw',1.5],[1,'Wall of Omens','1W',2,'C','draw',1.2],[1,'Mulldrifter','4U',5,'C','draw',0.3],[1,'Cloudblazer','3WU',5,'C','draw',0.2],[1,'Sphinx of Uthuun','5UU',7,'C','draw',0.3],[1,'Filigree Familiar','3',3,'C','draw',0.3],[1,'Land Tax','W',1,'E','draw',18],
 [1,'Sol Ring','1',1,'A','ramp',1.8,'FM'],[1,'Arcane Signet','2',2,'A','ramp',0.8],[1,'Azorius Signet','2',2,'A','ramp',0.5],[1,'Orzhov Signet','2',2,'A','ramp',0.5],[1,'Dimir Signet','2',2,'A','ramp',0.6],[1,'Talisman of Progress','2',2,'A','ramp',1.5],[1,'Talisman of Dominance','2',2,'A','ramp',1.8],[1,'Mind Stone','2',2,'A','ramp',0.4],[1,"Commander's Sphere",'3',3,'A','ramp',0.4],[1,'Hedron Archive','4',4,'A','ramp',0.5],[1,'Solemn Simulacrum','4',4,'C','ramp',3.5],
 [1,'Propaganda','2U',3,'E','prot',4],[1,'Ghostly Prison','2W',3,'E','prot',3],[1,'Windborn Muse','3W',4,'C','prot',0.5],
 [1,'Torrential Gearhulk','4UU',6,'C','mot',4],[1,'Sun Titan','4WW',6,'C','mot',2.5],[1,'Charming Prince','1W',2,'C','mot',1.5],[1,'Vendilion Clique','1UU',3,'C','mot',8],[1,'Dream Trawler','4WU',6,'C','mot',1.0],[1,'Archaeomancer','2UU',4,'C','mot',0.3],[1,'Teferi, Hero of Dominaria','3WU',5,'P','mot',11],[1,"Elspeth, Sun's Champion",'4WW',6,'P','mot',3],[1,'Approach of the Second Sun','6W',7,'S','mot',4]
];

const C_CARDS = [
 [12,'Island','',0,'L','land',0.1],[9,'Mountain','',0,'L','land',0.1],[1,'Command Tower','',0,'L','land',0.9],[1,'Steam Vents','',0,'L','land',12],[1,'Spirebluff Canal','',0,'L','land',9],[1,'Shivan Reef','',0,'L','land',1.5],[1,'Temple of Epiphany','',0,'L','land',0.5],[1,'Izzet Boilerworks','',0,'L','land',0.2],[1,'Evolving Wilds','',0,'L','land',0.2],[1,'Mystic Sanctuary','',0,'L','land',1.0],[1,'Desolate Lighthouse','',0,'L','land',0.3],[1,'Sulfur Falls','',0,'L','land',2.0],[1,'Cascade Bluffs','',0,'L','land',4.0],[1,'Riverglide Pathway','',0,'L','land',2.5],[1,'Frostboil Snarl','',0,'L','land',0.8],
 [1,'Temporal Manipulation','3UU',5,'S','mot',24,'EX'],[1,'Temporal Mastery','5UU',7,'S','mot',8,'EX'],[1,"Alrund's Epiphany",'5UU',7,'S','mot',4,'EX'],
 [1,'Fierce Guardianship','2UU',4,'I','ctr',34,'FREE'],[1,'Deflecting Swat','1RR',3,'I','prot',28,'FREE'],
 [1,'Mana Crypt','',0,'A','ramp',140,'GC'],[1,"Jeska's Will",'2R',3,'S','ramp',18,'GC'],[1,'Sol Ring','1',1,'A','ramp',1.8,'FM'],[1,'Mana Vault','1',1,'A','ramp',28,'FM'],
 [1,'Counterspell','UU',2,'I','ctr',1.1,'CTR'],[1,'Negate','1U',2,'I','ctr',0.3,'CTR'],[1,"An Offer You Can't Refuse",'U',1,'I','ctr',1.5,'CTR'],
 [1,'Blasphemous Act','8R',9,'S','wipe',1.9,'WIPE'],[1,'Chain Reaction','2RR',4,'S','wipe',0.5,'WIPE'],
 [1,'Mystical Tutor','U',1,'I','tut',6,'TUT'],
 [1,'Ponder','U',1,'S','draw',1.8],[1,'Preordain','U',1,'S','draw',1.2],[1,'Brainstorm','U',1,'I','draw',1.0],[1,'Opt','U',1,'I','draw',0.3],[1,'Treasure Cruise','7U',8,'S','draw',0.5],[1,'Fact or Fiction','3U',4,'I','draw',0.5],[1,'Pull from Tomorrow','XUU',2,'I','draw',0.8],[1,'Izzet Charm','UR',2,'I','draw',0.3],[1,'Expressive Iteration','UR',2,'S','draw',3],[1,'Light Up the Stage','2R',3,'S','draw',0.4],[1,'Big Score','3R',4,'I','draw',0.4],[1,'Unexpected Windfall','3R',4,'I','draw',0.3],[1,'Seize the Spoils','2R',3,'S','draw',0.2],[1,'Thrill of Possibility','1R',2,'I','draw',0.2],[1,'Valakut Awakening','2R',3,'I','draw',1.2],[1,'Curiosity','U',1,'E','draw',1.5],[1,'Steam Augury','1UR',3,'I','draw',0.3],
 [1,'Talrand, Sky Summoner','2UU',4,'C','tok',2],[1,'Murmuring Mystic','3U',4,'C','tok',0.4],[1,'Young Pyromancer','1R',2,'C','tok',1.5],[1,'Third Path Iconoclast','2',2,'C','tok',2.5],[1,'Sprite Dragon','UR',2,'C','tok',1.0],[1,'Improbable Alliance','UR',2,'E','tok',0.4],
 [1,'Archmage Emeritus','2UU',4,'C','draw',3.5],[1,'Niv-Mizzet, Parun','UUURRR',6,'C','draw',4],
 [1,'Storm-Kiln Artist','1R',2,'C','ramp',1.2],[1,'Birgi, God of Storytelling','2R',3,'C','ramp',2],[1,'Goldspan Dragon','3RR',5,'C','ramp',12],[1,'Arcane Signet','2',2,'A','ramp',0.8],[1,'Izzet Signet','2',2,'A','ramp',0.6],[1,'Talisman of Creativity','2',2,'A','ramp',1.4],[1,'Mind Stone','2',2,'A','ramp',0.4],[1,'Fellwar Stone','2',2,'A','ramp',1.0],
 [1,'Lightning Bolt','R',1,'I','rem',0.9],[1,'Chaos Warp','2R',3,'I','rem',1.2],[1,'Abrade','1R',2,'I','rem',0.3],[1,'Prismari Command','1UR',3,'I','rem',1.5],
 [1,'Guttersnipe','2R',3,'C','mot',0.5],[1,'Electrostatic Field','1R',2,'C','mot',0.3],[1,'Firebrand Archer','1R',2,'C','mot',0.2],[1,'Kessig Flamebreather','1R',2,'C','mot',0.3],[1,'Thousand-Year Storm','4UR',6,'E','mot',3],[1,'Dualcaster Mage','1RR',3,'C','mot',3],[1,'Increasing Vengeance','RR',2,'S','mot',1],[1,'Bonus Round','1RR',3,'S','mot',5],[1,'Reverberate','RR',2,'S','mot',0.5],[1,"Jace's Sanctum",'3U',4,'E','mot',1.5],[1,'Ral, Storm Conduit','2UR',4,'P','mot',3.5],[1,'Stormwing Entity','3UU',5,'C','mot',0.4],
 [1,"Narset's Reversal",'UU',2,'I','prot',8],[1,'Slip Out the Back','U',1,'I','prot',1.5],[1,'Bolt Bend','2R',3,'I','prot',0.4]
];

// dials: k -> [count, pts, markerPos%]
export const DECKS = {
 tier1: {arch:'aristocrats', cards:A_CARDS,
  dials:{gc:[0,0,3],ext:[0,0,3],tut:[3,1,42],stax:[0,0,3],ctr:[0,0,2],wipe:[3,0,38],free:[0,0,3],fm:[1,0,24],c1_5:[18,0,55],c10_20:[2,0,38],c20_30:[0,0,2]},
  chips:{tut:['Diabolic Tutor','Final Parting','Scheming Symmetry'],c10_20:['Elenda, the Dust Rose','Toxic Deluge']},
  viol:{es:[],en:[]},
  flags:{es:[],en:[]},
  tip:{es:'Mazo limpio de Tier 1: 1 punto de los 2 permitidos. Tienes margen para un game changer suave o un cuarto barrido sin salir de Tier 1 — pero recuerda que el tercer tutor ya te está cobrando.',
       en:'Clean Tier 1 deck: 1 point of the 2 allowed. You have room for a mild game changer or a fourth wipe without leaving Tier 1 — but remember the third tutor is already charging you.'}},
 tier2: {arch:'control', cards:B_CARDS,
  dials:{gc:[2,2,55],ext:[0,0,3],tut:[3,1,42],stax:[0,0,3],ctr:[5,2,58],wipe:[4,0,48],free:[0,0,3],fm:[1,0,24],c1_5:[15,0,48],c10_20:[4,0,55],c20_30:[2,0,48]},
  chips:{gc:['Rhystic Study','Smothering Tithe'],ctr:['Counterspell','Negate','Swan Song',"Dovin's Veto",'Arcane Denial'],tut:['Mystical Tutor','Enlightened Tutor','Idyllic Tutor']},
  viol:{es:[],en:[]},
  flags:{es:['Rhystic Study (€26) y Smothering Tithe (€22) rozan el límite de €30 — revisa precios antes de sentarte.'],
         en:['Rhystic Study (€26) and Smothering Tithe (€22) are close to the €30 cap — check prices before sitting down.']},
  tip:{es:'Para bajar a Tier 1 tienes que soltar 3 puntos: quita Rhystic Study (−2) y un contrahechizo (−1), o cambia Smothering Tithe (−2) y un tutor (−1) por robo genérico. El plan del mazo no cambia; su techo sí.',
       en:'To drop to Tier 1 you need to shed 3 points: cut Rhystic Study (−2) and one counterspell (−1), or swap Smothering Tithe (−2) and a tutor (−1) for generic draw. The deck’s plan stays; its ceiling drops.'}},
 above: {arch:'spellslinger', cards:C_CARDS,
  dials:{gc:[2,2,55],ext:[3,3,68],tut:[1,0,16],stax:[0,0,3],ctr:[4,0,48],wipe:[2,0,26],free:[2,2,58],fm:[3,2,72],c1_5:[14,0,45],c10_20:[2,0,38],c20_30:[3,0,52]},
  chips:{gc:['Mana Crypt',"Jeska's Will"],ext:['Temporal Manipulation','Temporal Mastery',"Alrund's Epiphany"],free:['Fierce Guardianship','Deflecting Swat'],fm:['Mana Crypt','Sol Ring','Mana Vault']},
  viol:{es:['Carta prohibida: Mana Crypt','Carta de más de €30: Fierce Guardianship (€34) — necesita aprobación explícita de la mesa'],
        en:['Banned card: Mana Crypt','Card over €30: Fierce Guardianship (€34) — needs explicit table approval']},
  flags:{es:['3 cartas de turno extra (Temporal Manipulation, Temporal Mastery, Alrund\u2019s Epiphany) — requieren justificación en mesa','3 cartas en €20–30 — con subidas de precio pueden cruzar el límite'],
         en:['3 extra-turn cards (Temporal Manipulation, Temporal Mastery, Alrund\u2019s Epiphany) — need table justification','3 cards in €20–30 — price spikes could push them over the cap']},
  tip:{es:'Este mazo necesita recortes para sentarse en el pod: Mana Crypt está prohibida (fuera sí o sí), cambia Fierce Guardianship por un contrahechizo normal (−2 pts y adiós violación) y deja solo 1 turno extra (−2 pts). Quedarías en 5/7: Tier 2 legal.',
       en:'This deck needs cuts to sit at the pod: Mana Crypt is banned (must go), swap Fierce Guardianship for a normal counterspell (−2 pts and the violation disappears) and keep only 1 extra turn (−2 pts). You would land at 5/7: legal Tier 2.'}}
};

export function listText(key){ return DECKS[key].cards.map(c=>c[0]+' '+c[1]).join('\n'); }
export function art(name){ return 'https://api.scryfall.com/cards/named?format=image&version=art_crop&exact='+encodeURIComponent(name); }
export function full(name){ return 'https://api.scryfall.com/cards/named?format=image&version=normal&exact='+encodeURIComponent(name); }
